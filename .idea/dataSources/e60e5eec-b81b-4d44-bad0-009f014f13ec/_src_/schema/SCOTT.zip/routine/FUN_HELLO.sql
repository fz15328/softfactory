CREATE function fun_hello(name emp.ename%type)
return varchar2 as


begin
  return 'Hello,'||name||'!';
end fun_hello;
/
