CREATE function tolsal(v_deptno emp.deptno%type)
return number as
   v_sal emp.sal%type;
begin
   select sum(sal) into v_sal from emp where deptno=v_deptno;
   return v_sal;
end tolsal;
/
