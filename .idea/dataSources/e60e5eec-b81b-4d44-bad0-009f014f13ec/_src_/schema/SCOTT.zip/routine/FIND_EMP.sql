CREATE procedure find_emp(
       v_empno emp.empno%type,
       v_ename out emp.ename%type
) as
  v_hello emp.ename%type := 'Hi.';
begin
  select ename into v_ename from emp where empno=v_empno;
  v_ename := v_hello||v_ename;
  exception
    when no_data_found then
      v_ename := v_empno||'no';
end find_emp;
/
