CREATE procedure exmp(
       username emp.ename%type,
       password emp.empno%type
)as
       v_pass emp.empno%type;

begin
    select empno into v_pass from emp where username=ename;

  if v_pass = password then
    dbms_output.put_line('登录成功！');
  elsif v_pass != password then
    dbms_output.put_line('密码错误！');
  end if;
  exception when no_data_found then
      dbms_output.put_line('用户不存在！');
end exmp;
/
