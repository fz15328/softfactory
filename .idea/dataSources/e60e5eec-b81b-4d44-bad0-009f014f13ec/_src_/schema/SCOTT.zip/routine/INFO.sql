CREATE procedure Info(
  i_empno emp.empno%type,
  i_ename out emp.ename%type
) as
  v_ename emp.ename%type;
  cursor i_emp is
  select ename from emp where empno=(select mgr from emp where empno= i_empno) for update;

begin
  open i_emp;
  loop
  fetch i_emp into v_ename;
  exit when i_emp%notfound;
  i_ename := v_ename;
  end loop;
  close i_emp;
end Info;
/
